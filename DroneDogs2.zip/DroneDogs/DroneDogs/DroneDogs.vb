﻿Public Class DroneDogsOrder

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        'Declare constants

        'Declare variables 

        'Extract user typed quantities from text boxes and convert to integers

        'Calculate total number of hot dogs ordered

        'Calculate subtotal, sales tax, and total amounts

        'Convert numbers back to text and display in text boxes


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles Button3.Click

        'Close form

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click

        'Display message box thanking the user

    End Sub

End Class
